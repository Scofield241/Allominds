import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

export default function AlloVote() {
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [voted, setVoted] = useState(false);
  const [selectedCandidate, setSelectedCandidate] = useState(null);

  const candidates = [
    { name: "Ali Bongo", votes: 40 },
    { name: "Raymond Ndong Sima", votes: 35 },
    { name: "Autre Candidat", votes: 25 },
  ];

  const handleVote = (candidate) => {
    setSelectedCandidate(candidate);
    setVoted(true);
  };

  return (
    <div className="p-4 max-w-2xl mx-auto">
      <h1 className="text-xl font-bold mb-4">AlloVote - Plateforme de Sondages Électoraux (Gabon)</h1>
      <Card className="mb-4 p-4">
        <CardContent>
          <h2 className="text-lg font-semibold">Inscription</h2>
          <Input 
            type="email" 
            placeholder="Votre email" 
            value={email} 
            onChange={(e) => setEmail(e.target.value)} 
            className="mb-2"
          />
          <Input 
            type="tel" 
            placeholder="Votre numéro de téléphone (+241)" 
            value={phone} 
            onChange={(e) => setPhone(e.target.value)}
            className="mb-2"
          />
          <Button> S'inscrire </Button>
        </CardContent>
      </Card>

      <Card className="mb-4 p-4">
        <CardContent>
          <h2 className="text-lg font-semibold">Votez pour un candidat</h2>
          {candidates.map((candidate) => (
            <Button 
              key={candidate.name} 
              className="m-2" 
              onClick={() => handleVote(candidate.name)}
              disabled={voted}
            >
              {candidate.name}
            </Button>
          ))}
          {voted && <p className="mt-2 text-green-600">Vous avez voté pour {selectedCandidate} !</p>}
        </CardContent>
      </Card>

      <Card className="p-4">
        <CardContent>
          <h2 className="text-lg font-semibold">Résultats du Sondage</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={candidates}>
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="votes" fill="#82ca9d" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}
